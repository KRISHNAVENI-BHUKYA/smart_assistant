# 📄 EZ Works GenAI Assignment - Smart Research Assistant

This project is a smart assistant that helps users understand large documents (PDF or TXT) through summarization, question answering, and interactive logic-based Q&A sessions.

---

## ✅ Features

- 📁 Upload PDF or TXT files
- 📌 Auto-generate concise document summary
- ❓ **Ask Anything** mode for user questions with referenced answers
- 🧠 **Challenge Me** mode for logic-based questions & answer evaluations
- 📎 Justifications provided from the document
- 🧪 Semantic similarity scoring for answer evaluation

---

## 🛠️ Tech Stack

| Layer       | Tools / Libraries                               |
|-------------|--------------------------------------------------|
| Frontend    | Streamlit                                       |
| Backend     | Python, Transformers, Sentence Transformers     |
| NLP Models  | `distilbert` (QA), `flan-t5` (QGen), `MiniLM` (Embedding) |
| PDF Parsing | pdfminer.six                                    |

---

## ⚙️ Setup Instructions

### 1. Clone Repository
```bash
git clone https://github.com/yourname/genai-assistant.git
cd genai-assistant
```

### 2. Create Virtual Environment
```bash
python -m venv venv
source venv/bin/activate   # Windows: venv\Scripts\activate
```

### 3. Install Dependencies
```bash
pip install -r requirements.txt
```

### 4. Run the App
```bash
streamlit run app.py
```

---

## 📁 Folder Structure
```
├── app.py
├── requirements.txt
├── README.md
└── utils/
    ├── pdf_reader.py
    ├── summarizer.py
    ├── qa_engine.py
    └── challenge_me.py
```

---

## 🧠 Models Used

| Task                     | Model                        |
|--------------------------|-------------------------------|
| Summarization            | bart-large-cnn                |
| Question Answering       | distilbert-base-uncased-distilled-squad |
| Question Generation      | google/flan-t5-base           |
| Answer Evaluation        | all-MiniLM-L6-v2              |

---

## 🔍 Evaluation Logic
- Answer evaluation is done via **semantic similarity**.
- A correct match: **similarity > 0.75**.
- Partial credit: **similarity between 0.4 and 0.75**.

---
