from transformers import pipeline

# Load the summarization model once
summarizer = pipeline("summarization")

# Generate summary of extracted text
def generate_summary(text):
    """
    Generate a summary of the given text using a pre-trained summarization model.

    Args:
        text (str): The text to be summarized.

    Returns:
        str: The generated summary or an error message if an exception is raised.
    """
    try:
        max_input_length = 1024
        input_text = text[:max_input_length]  # Limit input size for model

        summary = summarizer(input_text, max_length=150, min_length=50, do_sample=False)
        return summary[0]['summary_text']
    except Exception as e:
        return f"Error generating summary: {e}"
