from transformers import pipeline
from sentence_transformers import SentenceTransformer, util
import re

# Load pipelines
qa_pipeline = pipeline("question-answering")
embedding_model = SentenceTransformer("all-MiniLM-L6-v2")  # Lightweight, fast

# Split text into reasonable-sized paragraphs
def split_into_chunks(text, max_length=500):
    """
    Splits the input text into chunks based on paragraph breaks.

    Args:
        text (str): The input text to be split into chunks.
        max_length (int, optional): Maximum length of each chunk. Default is 500.

    Returns:
        list[str]: A list of text chunks, each stripped of leading and trailing whitespace, 
                   with a minimum length of 20 characters.
    """

    chunks = re.split(r'\n{2,}|\n', text)
    return [chunk.strip() for chunk in chunks if len(chunk.strip()) > 20]

# Find best paragraph for the given question
def find_most_relevant_chunk(chunks, question):
    """
    Find the most relevant paragraph in the given list of chunks to the given question.

    Args:
        chunks (list[str]): A list of paragraphs to search through.
        question (str): The question to answer.

    Returns:
        tuple: A tuple containing the best paragraph and its cosine similarity to the question.
    """
    question_embedding = embedding_model.encode(question, convert_to_tensor=True)
    chunk_embeddings = embedding_model.encode(chunks, convert_to_tensor=True)
    similarities = util.cos_sim(question_embedding, chunk_embeddings)[0]
    best_idx = similarities.argmax()
    return chunks[best_idx], float(similarities[best_idx])

# Get answer + justification
def answer_question_with_reference(context, question):
    """
    Find the answer to the given question within the given context.

    Args:
        context (str): The text to search for the answer
        question (str): The question to answer

    Returns:
        tuple: (answer, justification)
            answer (str): The answer to the question
            justification (str): Text explaining how the answer was arrived at
    """
    chunks = split_into_chunks(context)
    if not chunks:
        return "No content found in document.", "N/A"

    best_chunk, score = find_most_relevant_chunk(chunks, question)

    try:
        result = qa_pipeline(question=question, context=best_chunk)
        answer = result["answer"]
        return answer, f"Based on context: \"{best_chunk[:300]}...\" (Score: {score:.2f})"
    except Exception as e:
        return "Unable to answer", f"Error: {e}"
