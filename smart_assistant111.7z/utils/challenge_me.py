from transformers import pipeline
from sentence_transformers import SentenceTransformer, util
import re
import random

# Load models
qa_model = pipeline("question-answering")
generator = pipeline("text2text-generation", model="google/flan-t5-base")
embedder = SentenceTransformer("all-MiniLM-L6-v2")

# Split text into paragraph-level chunks
def split_into_chunks(text, max_len=500):
    """
    Split a document into meaningful chunks, for example paragraphs of text.

    Args:
        text (str): The document text to split into chunks.
        max_len (int, optional): The maximum number of characters in each chunk. Defaults to 500.

    Returns:
        list: A list of strings, each containing a chunk of text from the document.
    """
    paragraphs = re.split(r"\n{2,}|\n", text)
    return [p.strip() for p in paragraphs if len(p.strip()) > 20][:10]  # Limit for performance

# Generate Q&A pairs from meaningful chunks
def generate_questions(document_text):
    """
    Generate Q&A pairs from meaningful chunks of a document.

    Args:
        document_text (str): The document text to generate Q&A pairs from.

    Returns:
        list: A list of dictionaries, each containing a question, answer, and justification.
    """
    
    chunks = split_into_chunks(document_text)
    questions_and_answers = []

    for chunk in chunks:
        prompt = (
            "Read the following content and generate ONE logical question and its answer.\n\n"
            f"Context:\n{chunk}\n\n"
            "Format:\nQ: <question>\nA: <answer>\n"
        )

        try:
            output = generator(prompt, max_length=128, do_sample=True, num_return_sequences=1)
            result = output[0]["generated_text"].strip()
            # Fallback parsing logic
            if "Q:" in result and "A:" in result:
                question = result.split("Q:")[1].split("A:")[0].strip()
                answer = result.split("A:")[1].strip()
                if len(question) > 5 and len(answer) > 1:
                    questions_and_answers.append({
                        "question": question,
                        "answer": answer,
                        "justification": chunk
                    })
            else:
                if result: # Check if the generated text is not empty
                    questions_and_answers.append({
                        "question": result,
                        "answer": "N/A",
                        "justification": chunk
                    })

        except Exception as e:
            continue
    
    return random.sample(questions_and_answers, min(3, len(questions_and_answers)))


# Evaluate similarity between user's answer and correct answer
def evaluate_user_answers(user_answer, correct_answer):
    """
    Evaluate the similarity between user's answer and correct answer.

    Args:
        user_answer (str): User's answer to evaluate.
        correct_answer (str): Correct answer to compare with.

    Returns:
        str: A string indicating whether the user's answer is correct, partially correct, or incorrect.
    """
    if not user_answer or not correct_answer:
        return "❌ No answer provided."

    user_vec = embedder.encode(user_answer, convert_to_tensor=True)
    correct_vec = embedder.encode(correct_answer, convert_to_tensor=True)
    similarity = util.cos_sim(user_vec, correct_vec)[0].item()

    if similarity > 0.75:
        return "✅ Correct"
    elif similarity > 0.4:
        return f"🟡 Partially correct (Score: {similarity:.2f})"
    else:
        return f"❌ Incorrect (Score: {similarity:.2f})"
