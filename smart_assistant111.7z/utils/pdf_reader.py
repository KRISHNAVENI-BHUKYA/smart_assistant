from pdfminer.high_level import extract_text

# Extract text from a PDF file object
def extract_text_from_pdf(uploaded_file):
    """
    Extracts text from an uploaded PDF file.

    Args:
        uploaded_file: A file-like object representing the uploaded PDF file.

    Returns:
        The text content of the PDF file as a string if successful.
    """
    try:
        text = extract_text(uploaded_file)
        return text
    except Exception as e:
        return f"Error reading PDF: {e}"

# Extract text from a TXT file object
def extract_text_from_txt(uploaded_file):
    """
    Extracts text from an uploaded TXT file.

    Args:
        uploaded_file: A file-like object representing the uploaded TXT file.

    Returns:
        The text content of the TXT file as a string if successful.
        Returns an error message as a string if there is an exception.
    """

    try:
        text = uploaded_file.read().decode("utf-8")
        return text
    except Exception as e:
        return f"Error reading TXT file: {e}"
