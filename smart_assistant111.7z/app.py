import streamlit as st
from utils.pdf_reader import extract_text_from_pdf, extract_text_from_txt
from utils.summarizer import generate_summary
from utils.qa_engine import answer_question_with_reference
from utils.challenge_me import generate_questions, evaluate_user_answers

# Set Streamlit page config
st.set_page_config(page_title="EZ Works GenAI Assistant", layout="wide")

# Title
st.title("📄 EZ Works Smart Research Assistant")

# Sidebar for mode selection
st.sidebar.title("🧠 Interaction Mode")
mode = st.sidebar.radio("Choose a mode", ["Ask Anything", "Challenge Me"])

# File uploader
uploaded_file = st.file_uploader("Upload a PDF or TXT document", type=["pdf", "txt"])

# Session state for storing text and summary
if "document_text" not in st.session_state:
    st.session_state.document_text = ""
if "summary" not in st.session_state:
    st.session_state.summary = ""

# Process uploaded file
if uploaded_file:
    file_name = uploaded_file.name
    file_type = uploaded_file.type

    if file_type == "application/pdf":
        st.session_state.document_text = extract_text_from_pdf(uploaded_file)
    elif file_type == "text/plain":
        st.session_state.document_text = extract_text_from_txt(uploaded_file)
    else:
        st.warning("Unsupported file type. Please upload a PDF or TXT.")
        st.stop()

    # Generate and display summary
    with st.spinner("Generating summary..."):
        st.session_state.summary = generate_summary(st.session_state.document_text)

    st.subheader("📌 Document Summary")
    st.write(st.session_state.summary)

# Ask Anything Mode
if uploaded_file and mode == "Ask Anything":
    st.subheader("❓ Ask Anything from the Document")
    user_question = st.text_input("Type your question here:")

    if user_question:
        with st.spinner("Searching for the answer..."):
            answer, justification = answer_question_with_reference(
                context=st.session_state.document_text,
                question=user_question
            )
        st.markdown(f"**Answer:** {answer}")
        st.markdown(f"**Justification:** {justification}")

# Challenge Me Mode
if uploaded_file and mode == "Challenge Me":
    st.subheader("🧠 Comprehension Challenge")

    with st.spinner("Generating questions..."):
        questions_and_answers = generate_questions(st.session_state.document_text)

    user_answers = []
    for i, qa in enumerate(questions_and_answers):
        st.markdown(f"**Q{i+1}: {qa['question']}**")
        user_input = st.text_input(f"Your Answer to Q{i+1}", key=f"user_answer_{i}")
        user_answers.append({
            "user": user_input,
            "correct": qa["answer"],
            "reference": qa["justification"]
        })

    if st.button("Evaluate Answers"):
        for i, ua in enumerate(user_answers):
            result = evaluate_user_answers(ua["user"], ua["correct"])
            st.markdown(f"**Q{i+1} Result:** {result}")
            st.markdown(f"**Justification:** {ua['reference']}")

# Footer
st.markdown("---")
st.markdown("Developed by Krishnaveni B for EZ Works GenAI Assignment")
